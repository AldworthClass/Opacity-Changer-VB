﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmOpacityExample
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmOpacityExample))
        Me.imgSlimer = New System.Windows.Forms.PictureBox()
        Me.btnFadeIn = New System.Windows.Forms.Button()
        Me.btnFadeOut = New System.Windows.Forms.Button()
        Me.btnAppear = New System.Windows.Forms.Button()
        Me.trkOpacity = New System.Windows.Forms.TrackBar()
        Me.tmrFadeIn = New System.Windows.Forms.Timer(Me.components)
        Me.tmrFadeOut = New System.Windows.Forms.Timer(Me.components)
        Me.btnTimerFadeIn = New System.Windows.Forms.Button()
        Me.btnTimerFadeOut = New System.Windows.Forms.Button()
        Me.txtOpacity = New System.Windows.Forms.TextBox()
        Me.lblInstruction = New System.Windows.Forms.Label()
        Me.btnOpacityFromTextBox = New System.Windows.Forms.Button()
        CType(Me.imgSlimer, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.trkOpacity, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'imgSlimer
        '
        Me.imgSlimer.BackColor = System.Drawing.Color.Transparent
        Me.imgSlimer.Image = CType(resources.GetObject("imgSlimer.Image"), System.Drawing.Image)
        Me.imgSlimer.Location = New System.Drawing.Point(300, 125)
        Me.imgSlimer.Name = "imgSlimer"
        Me.imgSlimer.Size = New System.Drawing.Size(200, 185)
        Me.imgSlimer.TabIndex = 0
        Me.imgSlimer.TabStop = False
        '
        'btnFadeIn
        '
        Me.btnFadeIn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFadeIn.Location = New System.Drawing.Point(12, 17)
        Me.btnFadeIn.Name = "btnFadeIn"
        Me.btnFadeIn.Size = New System.Drawing.Size(73, 41)
        Me.btnFadeIn.TabIndex = 1
        Me.btnFadeIn.Text = "Fade In"
        Me.btnFadeIn.UseVisualStyleBackColor = True
        '
        'btnFadeOut
        '
        Me.btnFadeOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnFadeOut.Location = New System.Drawing.Point(12, 68)
        Me.btnFadeOut.Name = "btnFadeOut"
        Me.btnFadeOut.Size = New System.Drawing.Size(73, 42)
        Me.btnFadeOut.TabIndex = 2
        Me.btnFadeOut.Text = "Fade Out"
        Me.btnFadeOut.UseVisualStyleBackColor = True
        '
        'btnAppear
        '
        Me.btnAppear.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAppear.Location = New System.Drawing.Point(12, 122)
        Me.btnAppear.Name = "btnAppear"
        Me.btnAppear.Size = New System.Drawing.Size(73, 45)
        Me.btnAppear.TabIndex = 3
        Me.btnAppear.Text = "Appear"
        Me.btnAppear.UseVisualStyleBackColor = True
        '
        'trkOpacity
        '
        Me.trkOpacity.Location = New System.Drawing.Point(91, 122)
        Me.trkOpacity.Name = "trkOpacity"
        Me.trkOpacity.Size = New System.Drawing.Size(97, 45)
        Me.trkOpacity.TabIndex = 4
        Me.trkOpacity.Value = 10
        '
        'tmrFadeIn
        '
        '
        'tmrFadeOut
        '
        '
        'btnTimerFadeIn
        '
        Me.btnTimerFadeIn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTimerFadeIn.Location = New System.Drawing.Point(91, 16)
        Me.btnTimerFadeIn.Name = "btnTimerFadeIn"
        Me.btnTimerFadeIn.Size = New System.Drawing.Size(97, 42)
        Me.btnTimerFadeIn.TabIndex = 5
        Me.btnTimerFadeIn.Text = "Timer Fade In"
        Me.btnTimerFadeIn.UseVisualStyleBackColor = True
        '
        'btnTimerFadeOut
        '
        Me.btnTimerFadeOut.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnTimerFadeOut.Location = New System.Drawing.Point(91, 68)
        Me.btnTimerFadeOut.Name = "btnTimerFadeOut"
        Me.btnTimerFadeOut.Size = New System.Drawing.Size(97, 42)
        Me.btnTimerFadeOut.TabIndex = 6
        Me.btnTimerFadeOut.Text = "Timer Fade Out"
        Me.btnTimerFadeOut.UseVisualStyleBackColor = True
        '
        'txtOpacity
        '
        Me.txtOpacity.Location = New System.Drawing.Point(203, 38)
        Me.txtOpacity.Name = "txtOpacity"
        Me.txtOpacity.Size = New System.Drawing.Size(100, 20)
        Me.txtOpacity.TabIndex = 7
        '
        'lblInstruction
        '
        Me.lblInstruction.AutoSize = True
        Me.lblInstruction.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstruction.Location = New System.Drawing.Point(205, 17)
        Me.lblInstruction.Name = "lblInstruction"
        Me.lblInstruction.Size = New System.Drawing.Size(198, 16)
        Me.lblInstruction.TabIndex = 8
        Me.lblInstruction.Text = "Type an opacity value from 1-10"
        '
        'btnOpacityFromTextBox
        '
        Me.btnOpacityFromTextBox.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnOpacityFromTextBox.Location = New System.Drawing.Point(309, 36)
        Me.btnOpacityFromTextBox.Name = "btnOpacityFromTextBox"
        Me.btnOpacityFromTextBox.Size = New System.Drawing.Size(94, 23)
        Me.btnOpacityFromTextBox.TabIndex = 9
        Me.btnOpacityFromTextBox.Text = "Apply"
        Me.btnOpacityFromTextBox.UseVisualStyleBackColor = True
        '
        'frmOpacityExample
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.OpacityChanger.My.Resources.Resources.haunted_background
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.btnOpacityFromTextBox)
        Me.Controls.Add(Me.lblInstruction)
        Me.Controls.Add(Me.txtOpacity)
        Me.Controls.Add(Me.btnTimerFadeOut)
        Me.Controls.Add(Me.btnTimerFadeIn)
        Me.Controls.Add(Me.trkOpacity)
        Me.Controls.Add(Me.btnAppear)
        Me.Controls.Add(Me.btnFadeOut)
        Me.Controls.Add(Me.btnFadeIn)
        Me.Controls.Add(Me.imgSlimer)
        Me.Name = "frmOpacityExample"
        Me.Text = "See through ghost"
        CType(Me.imgSlimer, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.trkOpacity, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents imgSlimer As PictureBox
    Friend WithEvents btnFadeIn As Button
    Friend WithEvents btnFadeOut As Button
    Friend WithEvents btnAppear As Button
    Friend WithEvents trkOpacity As TrackBar
    Friend WithEvents tmrFadeIn As Timer
    Friend WithEvents tmrFadeOut As Timer
    Friend WithEvents btnTimerFadeIn As Button
    Friend WithEvents btnTimerFadeOut As Button
    Friend WithEvents txtOpacity As TextBox
    Friend WithEvents lblInstruction As Label
    Friend WithEvents btnOpacityFromTextBox As Button
End Class
