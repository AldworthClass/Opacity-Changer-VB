﻿Imports System.Drawing.Imaging

Public Class frmOpacityExample
    Dim dblOpacity As Double
    Public Shared Function ChangeOpacity(ByVal img As Image, ByVal opacityvalue As Single) As Bitmap
        Dim bmp As New Bitmap(img.Width, img.Height)
        Dim graphics__1 As Graphics = Graphics.FromImage(bmp)
        Dim colormatrix As New Imaging.ColorMatrix
        colormatrix.Matrix33 = opacityvalue
        Dim imgAttribute As New ImageAttributes
        imgAttribute.SetColorMatrix(colormatrix, ColorMatrixFlag.[Default], ColorAdjustType.Bitmap)
        graphics__1.DrawImage(img, New Rectangle(0, 0, bmp.Width, bmp.Height), 0, 0, img.Width, img.Height,
         GraphicsUnit.Pixel, imgAttribute)
        graphics__1.Dispose()
        Return bmp
    End Function

    Private Sub BtnFadeOut_Click(sender As Object, e As EventArgs) Handles btnFadeOut.Click
        imgSlimer.Image = ChangeOpacity(imgSlimer.Image, 0.8)
    End Sub

    Private Sub BtnFadeIn_Click(sender As Object, e As EventArgs) Handles btnFadeIn.Click
        imgSlimer.Image = ChangeOpacity(imgSlimer.Image, 1.2)
    End Sub

    Private Sub BtnAppear_Click(sender As Object, e As EventArgs) Handles btnAppear.Click
        imgSlimer.Image.Dispose()
        imgSlimer.Image = My.Resources.slimer
    End Sub

    Private Sub TrkOpacity_Scroll(sender As Object, e As EventArgs) Handles trkOpacity.Scroll
        dblOpacity = trkOpacity.Value / 10  'Turns value in TrackBar to decimal
        imgSlimer.Image.Dispose() 'Gets rid of old image
        imgSlimer.Image = My.Resources.slimer 'Resets image with full opacity
        imgSlimer.Image = ChangeOpacity(imgSlimer.Image, dblOpacity) 'Apples opacity value from TrackBars current position to image
    End Sub

    Private Sub BtnTimerFadeIn_Click(sender As Object, e As EventArgs) Handles btnTimerFadeIn.Click
        dblOpacity = 0  'starts with an invisible slimer, but is not necessary
        tmrFadeIn.Enabled = True
    End Sub

    Private Sub BtnTimerFadeOut_Click(sender As Object, e As EventArgs) Handles btnTimerFadeOut.Click
        dblOpacity = 1  'Starts with a fully opaque slimer, but is not necessary
        tmrFadeOut.Enabled = True
    End Sub

    Private Sub TmrFadeOut_Tick(sender As Object, e As EventArgs) Handles tmrFadeOut.Tick
        dblOpacity -= 0.1
        imgSlimer.Image.Dispose() 'Gets rid of old image
        imgSlimer.Image = My.Resources.slimer 'Resets image with full opacity
        imgSlimer.Image = ChangeOpacity(imgSlimer.Image, dblOpacity) 'Apples opacity value from TrackBars current position to image
        If dblOpacity <= 0 Then 'Turns off Timer when invisible
            tmrFadeOut.Enabled = False
        End If
    End Sub

    Private Sub TmrFadeIn_Tick(sender As Object, e As EventArgs) Handles tmrFadeIn.Tick
        dblOpacity += 0.1
        imgSlimer.Image.Dispose() 'Gets rid of old image
        imgSlimer.Image = My.Resources.slimer 'Resets image with full opacity
        imgSlimer.Image = ChangeOpacity(imgSlimer.Image, dblOpacity) 'Apples opacity value from TrackBars current position to image
        If dblOpacity >= 1 Then 'Turns off Timer when invisible
            tmrFadeIn.Enabled = False
        End If
    End Sub

    Private Sub BtnOpacityFromTextBox_Click(sender As Object, e As EventArgs) Handles btnOpacityFromTextBox.Click
        If IsNumeric(txtOpacity.Text) Then  'Makes sure number is entered
            dblOpacity = txtOpacity.Text / 10
            imgSlimer.Image.Dispose() 'Gets rid of old image
            imgSlimer.Image = My.Resources.slimer 'Resets image with full opacity
            imgSlimer.Image = ChangeOpacity(imgSlimer.Image, dblOpacity) 'Apples opacity value from TrackBars current position to image
        Else
            txtOpacity.Text = ""
        End If
    End Sub
End Class
